-- MoneyTag starter schema for Supabase (PostgreSQL)
-- Run in Supabase Dashboard > SQL Editor. Review before production launch.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'freelancer' check (role in ('freelancer','client','admin')),
  avatar_url text,
  bio text not null default '',
  skills text[] not null default '{}',
  connects integer not null default 100 check (connects >= 0),
  verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 5 and 120),
  description text not null check (char_length(description) between 20 and 5000),
  category text not null,
  budget numeric(12,2) not null check (budget > 0),
  status text not null default 'open' check (status in ('open','in_progress','completed','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  freelancer_id uuid not null references public.profiles(id) on delete cascade,
  cover_letter text not null check (char_length(cover_letter) between 10 and 3000),
  status text not null default 'pending' check (status in ('pending','accepted','rejected','withdrawn')),
  created_at timestamptz not null default now(),
  unique(job_id, freelancer_id)
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  reviewer_id uuid not null references public.profiles(id) on delete cascade,
  reviewee_id uuid not null references public.profiles(id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  comment text not null default '',
  created_at timestamptz not null default now(),
  unique(job_id, reviewer_id, reviewee_id),
  check (reviewer_id <> reviewee_id)
);

create index if not exists jobs_status_created_idx on public.jobs(status, created_at desc);
create index if not exists jobs_client_idx on public.jobs(client_id);
create index if not exists applications_job_idx on public.applications(job_id);
create index if not exists applications_freelancer_idx on public.applications(freelancer_id);

-- Create a profile row automatically for each new auth user.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
declare chosen_role text;
begin
  chosen_role := coalesce(new.raw_user_meta_data->>'role', 'freelancer');
  if chosen_role not in ('freelancer','client') then chosen_role := 'freelancer'; end if;
  insert into public.profiles(id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), chosen_role)
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.jobs enable row level security;
alter table public.applications enable row level security;
alter table public.reviews enable row level security;

-- Profiles are publicly readable for marketplace profiles; each user edits only their own.
drop policy if exists "Profiles visible to everyone" on public.profiles;
create policy "Profiles visible to everyone" on public.profiles for select using (true);
drop policy if exists "Users insert own profile" on public.profiles;
create policy "Users insert own profile" on public.profiles for insert with check (auth.uid() = id);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

-- Anyone can see open jobs; only the owning client can create/update/delete them.
drop policy if exists "Open jobs are public" on public.jobs;
create policy "Open jobs are public" on public.jobs for select using (status = 'open' or client_id = auth.uid());
drop policy if exists "Clients create own jobs" on public.jobs;
create policy "Clients create own jobs" on public.jobs for insert with check (
  client_id = auth.uid() and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'client')
);
drop policy if exists "Clients update own jobs" on public.jobs;
create policy "Clients update own jobs" on public.jobs for update using (client_id = auth.uid()) with check (client_id = auth.uid());
drop policy if exists "Clients delete own jobs" on public.jobs;
create policy "Clients delete own jobs" on public.jobs for delete using (client_id = auth.uid());

-- Freelancers manage their own applications; clients can read applications for their own jobs.
drop policy if exists "Application visibility" on public.applications;
create policy "Application visibility" on public.applications for select using (
  freelancer_id = auth.uid() or exists (select 1 from public.jobs j where j.id = job_id and j.client_id = auth.uid())
);
drop policy if exists "Freelancers apply as self" on public.applications;
create policy "Freelancers apply as self" on public.applications for insert with check (
  freelancer_id = auth.uid() and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'freelancer')
);
drop policy if exists "Freelancers update own application" on public.applications;
create policy "Freelancers update own application" on public.applications for update using (freelancer_id = auth.uid()) with check (freelancer_id = auth.uid());

-- Reviews visible to all; insert only if reviewer is logged in and not reviewing themselves.
drop policy if exists "Reviews public read" on public.reviews;
create policy "Reviews public read" on public.reviews for select using (true);
drop policy if exists "Users create own review" on public.reviews;
create policy "Users create own review" on public.reviews for insert with check (reviewer_id = auth.uid() and reviewer_id <> reviewee_id);

grant usage on schema public to anon, authenticated;
grant select on public.jobs, public.profiles, public.reviews to anon, authenticated;
grant insert, update, delete on public.jobs to authenticated;
grant insert, select, update on public.profiles to authenticated;
grant insert, select, update on public.applications to authenticated;
grant select, insert on public.reviews to authenticated;
